using System;
using Microsoft.AspNetCore.Mvc;

namespace ProjetoWeb.Controllers
{
    [Route("api/usuario")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        [HttpGet]
        [Route("listar")]
        public IActionResult Listar()
        {
            return null;
        }
    }
}