using System;

namespace ListaExercicio
{
    class Exer02{
        public static void Renderizar(){
            Console.WriteLine("Digite a idade da pessoa: ");
            int idade = Convert.ToInt32(Console.ReadLine());

            string pessoa = "";
            if(idade <= 13){
                pessoa = "Criança";
            }
            else if(idade > 13 && idade <= 18){
                pessoa = "Adolescente";
            }
            else{
                pessoa = "Adulto";
            }

            Console.Write(pessoa);
        }
    }
}