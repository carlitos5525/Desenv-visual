﻿using System;

namespace OrientacaoObjetos
{
    class Program
    {
        static void Main(string[] args)
        {
            Usuario usuario = new Usuario();
            usuario.setNome("Carlos");
            Console.WriteLine($"Nome do usuário: {usuario.getNome()}");

            Produto produto1 = new Produto();
            produto1.Nome = "chave";
            Console.WriteLine(produto1.Nome);

            Produto produto2 = new Produto
            {
                Nome = "Coca",
                Preco = 5
            };
            Console.WriteLine(produto2.Nome);
        }
    }
}
