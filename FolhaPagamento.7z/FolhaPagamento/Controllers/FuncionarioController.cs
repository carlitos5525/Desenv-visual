using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace FolhaPagamento.Controllers
{
    [Route("api/funcionario")]
    [ApiController]
    public class FuncionarioController : ControllerBase
    {
         private static List<Funcionario> funcionarios = new List<Funcionario>();

        [HttpGet]
        [Route("listar")]
        public IActionResult Listar()
        {
            return Ok(funcionarios);
        }

        // POST /api/usuario/cadastrar
        [HttpPost]
        [Route("cadastrar")]
        public IActionResult Cadastrar([FromBody]Funcionario funcionario)
        {
            funcionarios.Add(funcionario);            
            return Created("", funcionario);
        }

        [HttpGet]
        [Route("buscar/{cpf}")]
        public IActionResult Buscar([FromRoute]string cpf)
        {
            //Expressão Lambda (tal que)
            // Funcionario funcionario = funcionarios.FirstOrDefault
            // (
            //     f => f.Cpf.Equals(cpf)
            // );
            // if (funcionario != null)
            // {
            //     return Ok(funcionario);
            // }
            // return NotFound();

            foreach(Funcionario funcionario in funcionarios)
            {
               if(funcionario.Cpf.Equals(cpf))
              {
                   return Ok(funcionario);
               }
            }
            
            return NotFound();

        }

        //DELETE: /api/funcionario/deletar/123
        [HttpDelete]
        [Route ("excluir/{cpf}")]
        public IActionResult Excluir([FromRoute] string cpf)
        {
            foreach (var funcionarioCadastrado in funcionarios)
            {
                if(funcionarioCadastrado.Cpf.Equals(cpf))
                {
                    funcionarios.Remove(funcionarioCadastrado);
                    return Ok(funcionarioCadastrado);
                }
                
            }
            
            return NotFound();
        }

        // api/funcionario/editar
        [HttpPatch]
        [Route ("editar")]
        public IActionResult Editar([FromBody]Funcionario funcionario)
        {
            Funcionario funcionario_cadastrado = funcionarios.FirstOrDefault
            (
                f => f.Cpf.Equals(funcionario.Cpf)
            );
            if (funcionario_cadastrado != null)
            {
                funcionario_cadastrado.Nome = funcionario.Nome;
                funcionario_cadastrado.Nascimento = funcionario.Nascimento;
                return Ok(funcionario_cadastrado);
            }

            return NotFound();


        }


    }
}