﻿using System;

namespace ListaExercicio
{
    class Program
    {
        static void Main(string[] args)
        {
            Exer01.Renderizar();
            Exer02.Renderizar();
        }
    }
}
