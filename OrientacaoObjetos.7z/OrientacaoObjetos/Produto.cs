using System;

namespace OrientacaoObjetos
{
    class Produto
    {
        public string Nome {get; set;}
        public double Preco {get; set;}

    }
}