using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using FolhaPagamento.Models.Funcionario;

namespace  FolhaPagamento.Controllers
{
    [Route("api/funcionario")]
    [ApiController]
    public class FuncionarioController : ControllerBase
    {
         private static List<Funcionario> funcionarios = new List<Funcionario>();

        [HttpGet]
        [Route("listar")]
        public IActionResult Listar()
        {
            return Ok(funcionarios);
        }

        // POST /api/usuario/cadastrar
        [HttpPost]
        [Route("cadastrar")]
        public IActionResult Cadastrar([FromBody]Funcionario funcionario)
        {
            funcionarios.Add(funcionario);            
            return Created("", funcionario);
        }

        [HttpGet]
        [Route("buscar/{cpf}")]
        public IActionResult Buscar([FromRoute]string cpf)
        {
            foreach(Funcionario funcionario in funcionarios)
            {
                if(funcionario.Nome == cpf)
                {
                    return Ok(funcionario);
                }
                else
                {
                    return NotFound();
                }
            }

            return Ok();
        }

    }
}