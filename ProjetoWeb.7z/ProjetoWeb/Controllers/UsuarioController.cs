using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using ProjetoWeb.Models.Usuario;

namespace ProjetoWeb.Controllers
{
    [Route("api/usuario")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        private static List<Usuario> usuarios = new List<Usuario>();

        [HttpGet]
        [Route("listar")]
        public IActionResult Listar()
        {
            return Ok(usuarios);
        }

        // POST /api/usuario/cadastrar
        [HttpPost]
        [Route("cadastrar")]
        public IActionResult Cadastrar([FromBody]Usuario usuario)
        {
            usuarios.Add(usuario);            
            return Created("", usuario);
        }

        [HttpGet]
        [Route("buscar/{login}")]
        public IActionResult Buscar([FromRoute]string login)
        {
            foreach(Usuario usuario in usuarios)
            {
                if(usuario.Login == login)
                {
                    return Ok(usuario);
                }
                else
                {
                    return NotFound();
                }
            }

            return Ok();
        }

    }
}