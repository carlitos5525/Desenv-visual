using System;

namespace FolhaPagamento.Models;
{
    public class Funcionario
    {
        public Funcionario()
        {
            CriadoEm = DateTime.Now;
        }
        
        public int Id {get; set;}
        public String Nome {get; set;}
        public String Cpf {get; set;}
        public DateTime Nascimento {get; set;}
        public DateTime CriadoEm {get; set;}

    }
}