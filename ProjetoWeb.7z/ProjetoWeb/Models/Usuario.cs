using System;

namespace ProjetoWeb.Models.Usuario
{
    public class Usuario
    {
        public string Login {get; set;}
        public string Senha {get; set;}
        public DateTime CriadoEm {get; set;}

        public Usuario()
        {
            this.CriadoEm = DateTime.Now;
        }
    }
}